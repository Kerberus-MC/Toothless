

  :::::::::                      ::::       :: ::                    :::   :::
    ::   ::                      ::         ::                        ::   ::
    ::   ::   :::::              :: ::::::: :: :: :::::::: :::::::    ::: :::
    ::   ::      :: ::::::: ::::::: ::   :: :: :: ::    :: ::   ::      :::
    ::   :: ::::::: ::   :: ::   :: ::::::: :: :: :: :: :: ::   ::    ::: :::
    ::   :: ::   :: ::   :: ::   :: ::      :: :: ::    :: ::   ::    ::   ::
  ::::::::: ::::::: ::   :: ::::::: ::::::: :: :: :::::::: ::   :::  :::   :::
                         ::
                    ::   ::::

                  ::::::    ::::::::                    ::
                  ::  ::    ::                          ::
                  ::        ::     :::::: :::::: :::::: ::
                ::::::      :::::: ::  :: ::  :: ::     ::::::
                ::          ::     ::     :::::: :::::: ::  ::
                ::    ::    ::     ::     ::         :: ::  ::
                ::::::::    ::     ::     :::::: :::::: ::  ::
                                                            ::::
      ::::::::    ::  ::                   ::   ::
      ::    ::	                           ::
      ::    :: :::::: :: ::::::::   :::: :::::: :: :::::::: :::::: ::::::
      :::::::: ::  :: :: :: :: ::     ::   ::   :: ::    :: ::  :: ::
      ::    :: ::  :: :: ::    :: ::::::   ::   :: :: :: :: ::  :: ::::::
      ::    :: ::  :: :: ::    :: ::  ::   ::   :: ::    :: ::  ::     ::
 ...::::.  .::.::  ::.::.::.  .::.::::::::.::::.::.::::::::.::  ::::.::::...
...................::........................................................
                   ::::




 				    I N S T R U C T I O N S 
				   :▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓:


1. Move "Dandelion X & Fresh Animations v1.1.zip" to the Resourcepack folder.
       (Click the "Open Pack Folder" button in the "Resource Packs..." menu in 
	  Minecraft Options to quickly access the folder.)

2. Download "Fresh Animations Beta 1.8.zip" and move it to the Resource Pack folder.

3. Download the latest Dandelion X release and move it to the Resource Pack folder.

4. In the "Resource Packs..." menu, arrange the 3 Resource Packs like so:
	1. Dandelion X & Fresh Animations v1.1.zip
	2. Fresh Animations Beta 1.8.zip (Or Newer)
	3. Dandelion X 1.19 Release 4.zip (Or Newer)




  				       C H A N G E L O G 
				      :▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓:



3/29/2022
Dandelion X & Fresh Animations v1.1 (Minecraft 1.19.4 and Fresh Animations Beta v1.8)
███████████████████████████████████████████████████████████████████████████████████


 Added support for all mobs updated in Fresh Animations v1.8
 Fixed Z-fighting texture on Horse Reins








12/18/2022
Dandelion X & Fresh Animations v1 (Minecraft 1.19.2 and Fresh Animations Beta v1.7)
███████████████████████████████████████████████████████████████████████████████████


 Initial Release, including support for all supported Fresh Animations Mobs







